# Techsurge'n Mridang 2k17

Android App for TnM17, Annual Fest of MAIT 2k17


<a href="https://play.google.com/store/apps/details?id=com.codingblazer.sachinaggarwal.tnm17">
  <img alt="Get it on Google Play"
       src="https://developer.android.com/images/brand/en_generic_rgb_wo_45.png" />
</a>

# Application's Features

### Home
This shows the glimpse of Annual Fest TnM(2k16-2k17) , displays Image gallery of Annual Fest and College.

### Events
This feature helps the attendees to see all the events along with all the required information       
(Time,Venue,Duration,Prizes,Registration Fee etc). Attendees can also mark any event as their
favourite one and leave no chance to miss it!

### Map
This feature helps Attendees to navigate to particular event that shows the complete direction in order to make user exerience better.

### Screenshots

<img src="https://user-images.githubusercontent.com/13872065/31575215-116ab86e-b0ff-11e7-99f3-6a6d0f08f66d.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575216-11adfab6-b0ff-11e7-8a00-01936dbc88c5.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575217-12f13b0e-b0ff-11e7-833d-81efe6994192.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575218-13eda4ca-b0ff-11e7-8dc8-1b183162c08d.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575221-1d4ec7a6-b0ff-11e7-8af0-64d3b2cff93e.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575222-1decce88-b0ff-11e7-8ca9-ab10bc99a941.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575223-2264a0b2-b0ff-11e7-8540-9439cca9ffaa.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575224-2371994c-b0ff-11e7-9704-bedcbabc301f.png" height="600" width="350">  <img src="https://user-images.githubusercontent.com/13872065/31575225-2453810e-b0ff-11e7-8b2d-042e93af74ba.png" height="600" width="350">



